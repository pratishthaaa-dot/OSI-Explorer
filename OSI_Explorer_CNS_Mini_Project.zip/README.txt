OSI EXPLORER — CNS MINI PROJECT

FILES
- index.html: Complete website; no external libraries required.
- OSI_Explorer_Project_Report.docx: Project report, test plan, limitations and viva questions.

HOW TO RUN
1. Extract this ZIP file.
2. Open index.html in Chrome, Edge, Firefox or another modern browser.
3. Choose Layer Explorer, Transmission Simulator or Quick Quiz.
4. For editing, open index.html in Visual Studio Code.

DEMO
1. Click each OSI layer and explain its responsibility.
2. Open Transmission Simulator and enter a message.
3. Click Start / Restart, then Next step to show sender-side encapsulation and receiver-side decapsulation.
4. Open Quick Quiz and answer the questions.

IMPORTANT
This is an educational simulation, not a real packet capture or network transmission tool. Header values are illustrative. Be clear about this during the viva.
